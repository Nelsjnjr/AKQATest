﻿using GlobalContantsApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;

namespace WordConvertor
{

    /// <summary>
    /// This class is use to convert the the currency input and convert it to word format
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class ConvertCurrencyToWordConvertor : WebService, ICurrencyConvertor
    {
        public ICurrencyConvertorInfo currencyInfo { get; set; }
        Dictionary<int, string> onesAndTeens = new Dictionary<int, string>();
        Dictionary<int, string> tens = new Dictionary<int, string>();

        /// <summary>
        /// Constructor of the service class which is responsible for parameter and object mapping
        /// </summary>
        public ConvertCurrencyToWordConvertor()
        {
            //Storing words of numbers to dictionary from 1 to 19
            onesAndTeens[0] = "ZERO";
            onesAndTeens[1] = "ONE";
            onesAndTeens[2] = "TWO";
            onesAndTeens[3] = "THREE";
            onesAndTeens[4] = "FOUR";
            onesAndTeens[5] = "FIVE";
            onesAndTeens[6] = "SIX";
            onesAndTeens[7] = "SEVEN";
            onesAndTeens[8] = "EIGHT";
            onesAndTeens[9] = "NINE";
            onesAndTeens[10] = "TEN";
            onesAndTeens[11] = "ELEVEN";
            onesAndTeens[12] = "TWELVE";
            onesAndTeens[13] = "THIRTEEN";
            onesAndTeens[14] = "FOURTEEN";
            onesAndTeens[15] = "FIFTEEN";
            onesAndTeens[16] = "SIXTEEN";
            onesAndTeens[17] = "SEVENTEEN";
            onesAndTeens[18] = "EIGHTEEN";
            onesAndTeens[19] = "NINETEEN";

            //Storing multiple of tens words  to dictionary from 20 to 90
            tens[2] = "TWENTY";
            tens[3] = "THIRTY";
            tens[4] = "FORTY";
            tens[5] = "FIFTY";
            tens[6] = "SIXTY";
            tens[7] = "SEVENTY";
            tens[8] = "EIGHTY";
            tens[9] = "NINETY";
            //Setting object
            currencyInfo = new CurrencyConvertorInfo();
        }

        /// <summary>
        /// This method is used to get the input from the client and process it to convert in to word format
        /// </summary>
        /// <param name="input">Currency input for conversion</param>
        /// <returns>Word format of currency name</returns>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string ConvertTheInputCurrencyToWord(string CurrencyValue, string Name)
        {


            string[] curencyParts = null;
            StringBuilder currencyToWord = new StringBuilder();
            string validationError = String.Empty;
            JavaScriptSerializer js = new JavaScriptSerializer();
            //Check the field validation
            ValidateInput(CurrencyValue, Name, out validationError);
            if (String.IsNullOrEmpty(validationError))
            {
                //Convert the input currency with two decimal places
                string convertedCurrency = String.Format("{0:0.##}", Convert.ToDecimal(CurrencyValue));
                currencyInfo.OutputCurrencyWithCents = convertedCurrency;
                if (convertedCurrency.IndexOf('.') > 0)
                {
                    //Spliting the currency based on period two convert into words for each
                    curencyParts = convertedCurrency.Split('.');
                    currencyToWord.Append(String.Format("{0} {1} {2} ", ConvertCurrentToWords(Convert.ToInt32(curencyParts[0])), GlobalConstants.DOLLARS, GlobalConstants.AND));
                    currencyToWord.Append(String.Format("{0} {1} ", ConvertCurrentToWords(Convert.ToInt32(curencyParts[1])), GlobalConstants.CENTS));
                    currencyInfo.OutputCurrencyAsWord = currencyToWord.ToString().Trim();
                }
                else
                {
                    currencyToWord.Append(String.Format("{0} {1} ", ConvertCurrentToWords(Convert.ToInt32(convertedCurrency)), GlobalConstants.DOLLARS));
                    currencyInfo.OutputCurrencyAsWord = currencyToWord.ToString().Trim();
                }
            }
            else
                currencyInfo.ValidationError = validationError.TrimEnd(',', ' ');
            currencyInfo.InputCurrency = CurrencyValue;
            currencyInfo.InputName = Name;
            //Serialize this object to json
            return js.Serialize(currencyInfo);


        }
        /// <summary>
        /// Converts the currency to words by recursively calling iterating through the currency by dividing and finding remainder 
        /// </summary>
        /// <param name="inputCurrency">Input currency for word conversion</param>
        /// <returns>Word format of currency</returns>
        private string ConvertCurrentToWords(int inputCurrency)
        {
            //Denominations
            int[] denomination = new int[] { 1000000, 1000, 100 };
            StringBuilder currencyWord = new StringBuilder();
            if (inputCurrency == 0)
                return onesAndTeens[0];//Get value for "0" ie) ZERO

            if ((inputCurrency / denomination[0]) > 0)//This will get million
            {
                //Divide the input with 1000000 to see how many of it available 
                currencyWord.Append(String.Format("{0} {1} ", ConvertCurrentToWords(inputCurrency / denomination[0]), GlobalConstants.MILLION));
                //Assign the remainder inputCurrency to process again recursively
                inputCurrency %= denomination[0];
            }
            if ((inputCurrency / denomination[1]) > 0)//This will get all thousands
            {
                //Divide the input with 1000 to see how many of it available 
                currencyWord.Append(String.Format("{0} {1} ", ConvertCurrentToWords(inputCurrency / denomination[1]), GlobalConstants.THOUSAND));
                //Assign the remainder inputCurrency to process again recursively
                inputCurrency %= denomination[1];
            }
            if ((inputCurrency / denomination[2]) > 0)//This will get all hundreds
            {
                //Divide the input with 100 to see how many of it available 
                currencyWord.Append(String.Format("{0} {1} ", ConvertCurrentToWords(inputCurrency / denomination[2]), GlobalConstants.HUNDRED));
                //Assign the remainder inputCurrency to process again recursively
                inputCurrency %= denomination[2];
            }
            //After hundreds overs we are left with tens and ones
            if (inputCurrency > 0)
            {
                //if all hundreds overs then we need to append "AND" and then the tens and ones
                if (!String.IsNullOrEmpty(currencyWord.ToString()))
                    currencyWord.Append(" AND ");
                //Checking the last two digit numbers whether it is less than 19 or greater than it,
                //if less we will get the value from dictionary
                if (inputCurrency <= 19)
                    currencyWord.Append(onesAndTeens[inputCurrency]);

                else
                {
                    // if greater than 19 then we need to divide the numbers with 10 to see howmany 10's available in it(get the value from tens dictionary).
                    //After that get the remainder and get the value from ones ditionary
                    currencyWord.Append(String.Format("{0} - ", tens[inputCurrency / 10]));
                    if ((inputCurrency % 10) > 0)
                        currencyWord.Append(onesAndTeens[inputCurrency % 10]);
                }
            }
            return currencyWord.ToString();
        }
        /// <summary>
        /// Validate the inputs
        /// </summary>
        /// <param name="CurrencyValue">Input currency for word conversion</param>
        /// <param name="Name">Name of the person</param>
        /// <param name="ValidaionError">Captures any validation error</param>
        private void ValidateInput(string CurrencyValue, string Name, out string ValidaionError)
        {
            ValidaionError = String.Empty;
            if (String.IsNullOrEmpty(CurrencyValue))
            {
                ValidaionError += GlobalConstants.CurrencyRequired;
            }
            if (!String.IsNullOrEmpty(CurrencyValue) && !Regex.IsMatch(CurrencyValue, GlobalConstants.RegexValidNumber))
            {
                ValidaionError += GlobalConstants.CurrencyIsNotValid;
            }
            if (String.IsNullOrEmpty(Name))
            {
                ValidaionError += GlobalConstants.NameRequired;
            }
            if (!String.IsNullOrEmpty(Name) && Regex.IsMatch(Name, GlobalConstants.RegexValidNumber))
            {
                ValidaionError += GlobalConstants.NameIsNotValid;
            }
        }
    }
}