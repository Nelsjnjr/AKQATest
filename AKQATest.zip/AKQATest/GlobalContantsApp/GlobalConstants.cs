﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalContantsApp
{
    /// <summary>
    /// This file is used to have all the constants needs by the application instead of hardcoding
    /// This helps to maintain less dependencies
    /// </summary>
    public class GlobalConstants
    {
        public const string MILLION = "MILLON";
        public const string THOUSAND = "THOUSAND";
        public const string HUNDRED = "HUNDRED";
        public const string DOLLARS = "DOLLARS";
        public const string CENTS = "CENTS";
        public const string AND = "AND ";
        public const string NameRequired = "Name Required ,";
        public const string NameIsNotValid = "Name should be character ,";
        public const string CurrencyRequired = "Currency Required,";
        public const string CurrencyIsNotValid = "Invalid currency,";
        public const string RegexValidNumber = @"^[0-9]+(\.[0-9]+)?$";
    }
}
