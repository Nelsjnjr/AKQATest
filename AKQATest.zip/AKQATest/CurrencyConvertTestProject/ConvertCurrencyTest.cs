﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Script.Serialization;
using WordConvertor;


namespace CurrencyConvertTestProject
{
    /// <summary>
    /// This project is used to execute test cases
    /// </summary>
    [TestClass]
    public class CurrencyConvertorTestCases
    {

        private ICurrencyConvertorInfo currentDetails;
        private ICurrencyConvertor convertor;
        private JavaScriptSerializer js;
        [TestInitialize]
        public void TestInitialize()
        {
            //DI is not used as it is not required for thi application
            currentDetails = new CurrencyConvertorInfo();
            convertor = new ConvertCurrencyToWordConvertor();
            js = new JavaScriptSerializer();
        }
        /// <summary>
        /// validate currency is valid
        /// </summary>
        [TestMethod]
        public void CheckInputCurrencyIsValid()
        {

            string CurrencyInput = "Invalid";
            string Name = "Test";
            ICurrencyConvertorInfo currencyDetails = js.Deserialize<CurrencyConvertorInfo>(convertor.ConvertTheInputCurrencyToWord(CurrencyInput, Name));
            Assert.AreEqual("Invalid currency", currencyDetails.ValidationError);
        }
        /// <summary>
        /// Validate currency required
        /// </summary>
        [TestMethod]
        public void CheckInputCurrencyIsRequired()
        {

            string CurrencyInput = String.Empty;
            string Name = "Test";
            ICurrencyConvertorInfo currencyDetails = js.Deserialize<CurrencyConvertorInfo>(convertor.ConvertTheInputCurrencyToWord(CurrencyInput, Name));
            Assert.AreEqual("Currency Required", currencyDetails.ValidationError);
        }
        /// <summary>
        /// Valdate name required
        /// </summary>
        [TestMethod]
        public void CheckUserNameIsRequired()
        {

            string CurrencyInput = "2008.245";
            string Name = String.Empty;

            ICurrencyConvertorInfo currencyDetails = js.Deserialize<CurrencyConvertorInfo>(convertor.ConvertTheInputCurrencyToWord(CurrencyInput, Name));
            Assert.AreEqual("Name Required", currencyDetails.ValidationError);
        }
        /// <summary>
        /// Valid name as no numbers
        /// </summary>
        [TestMethod]
        public void CheckUserNameIsValid()
        {

            string CurrencyInput = "10989";
            string Name = "232323";

            ICurrencyConvertorInfo currencyDetails = js.Deserialize<CurrencyConvertorInfo>(convertor.ConvertTheInputCurrencyToWord(CurrencyInput, Name));
            Assert.AreEqual("Name should be character", currencyDetails.ValidationError);
        }
        /// <summary>
        /// validate username not modified by this process
        /// </summary>
        [TestMethod]
        public void CheckUserNameReturnedIsCorrectWithOutModified()
        {

            string CurrencyInput = "10989";
            string Name = "Test";

            ICurrencyConvertorInfo currencyDetails = js.Deserialize<CurrencyConvertorInfo>(convertor.ConvertTheInputCurrencyToWord(CurrencyInput, Name));
            Assert.AreEqual("Test", currencyDetails.InputName);
        }
        /// <summary>
        /// validate decimal places of currency provided
        /// </summary>
        [TestMethod]
        public void CheckIfCurrencyRoundUpForTwoDecimalPlaces()
        {

            string CurrencyInput = "2008.245";
            string Name = "Test";

            ICurrencyConvertorInfo currencyDetails = js.Deserialize<CurrencyConvertorInfo>(convertor.ConvertTheInputCurrencyToWord(CurrencyInput, Name));
            Assert.AreEqual("2008.25", currencyDetails.OutputCurrencyWithCents);
        }
        /// <summary>
        /// Validate the currency converted into word
        /// </summary>
        [TestMethod]
        public void CheckTheCurrencyConvertedWord()
        {

            string CurrencyInput = "2008.245";
            string Name = "Test";

            ICurrencyConvertorInfo currencyDetails = js.Deserialize<CurrencyConvertorInfo>(convertor.ConvertTheInputCurrencyToWord(CurrencyInput, Name));
            Assert.AreEqual("TWO THOUSAND  AND EIGHT DOLLARS AND  TWENTY - FIVE CENTS", currencyDetails.OutputCurrencyAsWord);
        }
        [TestCleanup]
        public void TestCleanup()
        {
            this.js = null;
            this.convertor = null;
        }
    }
}


