﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordConvertor
{
    /// <summary>
    /// The interface is used to force the implemented class to use this method to process word from currency
    /// </summary>
    public interface ICurrencyConvertor
    {

        string ConvertTheInputCurrencyToWord(string CurrencyValue, string Name);
    }


}
