﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordConvertor
{
    /// <summary>
    /// The class is used to process word from currency
    /// </summary>
    [Serializable]
    public class CurrencyConvertorInfo: ICurrencyConvertorInfo
    {
        public string OutputCurrencyAsWord
        {
            get;
            set;
        }
        public string InputCurrency
        {
            get;
            set;
        }
        public string InputName
        {
            get;
            set;
        }
        public string ValidationError
        {
            get;
            set;
        }
        public string OutputCurrencyWithCents
        {
            get;
            set;
        }
    }
}
