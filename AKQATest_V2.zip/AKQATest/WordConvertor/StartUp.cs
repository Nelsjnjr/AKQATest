﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
[assembly: PreApplicationStartMethod(typeof(WordConvertor.ObjectCreationByDI), "Start")]
namespace WordConvertor
{
    /// <summary>
    /// This class is used to inject the object for the interface dynamically
    /// </summary>
    public class ObjectCreationByDI
    {

        
        /// <summary>
        /// This method is used to injet dependency
        /// </summary>
        /// <returns>Injected objects</returns>
        public static ICurrencyConvertorInfo Start()
        {
            IUnityContainer objContainer = new UnityContainer();
            objContainer.RegisterType<ICurrencyConvertorInfo, CurrencyConvertorInfo>();
            ICurrencyConvertorInfo currencyInfo = objContainer.Resolve<ICurrencyConvertorInfo>();
            return currencyInfo;
        }
    }
}
