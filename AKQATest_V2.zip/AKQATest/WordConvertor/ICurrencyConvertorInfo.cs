﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordConvertor
{
    /// <summary>
    /// Interface that have all necessary properties for CurrencyConvertor
    /// </summary>
    public interface ICurrencyConvertorInfo
    {
         string OutputCurrencyAsWord
        {
            get;
            set;
        }
         string InputCurrency
        {
            get;
            set;
        }
         string InputName
        {
            get;
            set;
        }
         string ValidationError
        {
            get;
            set;
        }
         string OutputCurrencyWithCents
        {
            get;
            set;
        }

    }
   
       
    
}
