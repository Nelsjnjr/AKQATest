﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Script.Serialization;
using WordConvertor;

[assembly: PreApplicationStartMethod(typeof(CurrencyConvertTestProject.ObjectCreationByDI), "Start")]
namespace CurrencyConvertTestProject
{
    /// <summary>
    /// This class is used to inject the object for the interface dynamically
    /// </summary>
    public class ObjectCreationByDI
    {
        /// <summary>
        /// This method is used to injet dependency
        /// </summary>
        /// <returns>Injected objects</returns>
        public static void Start(out ICurrencyConvertor currencyInfo, out ICurrencyConvertorInfo CurrencyConvertorInfo)
        {
            
            currencyInfo = null;
            CurrencyConvertorInfo = null;
            IUnityContainer objContainer = new UnityContainer();
           // objContainer.RegisterType<JavaScriptSerializer>();
            objContainer.RegisterType<ICurrencyConvertorInfo, CurrencyConvertorInfo>();
            objContainer.RegisterType<ICurrencyConvertor, ConvertCurrencyToWordConvertor>();

            currencyInfo = objContainer.Resolve<ICurrencyConvertor>();
            CurrencyConvertorInfo = objContainer.Resolve<ICurrencyConvertorInfo>();
            //js = objContainer.Resolve<JavaScriptSerializer>();

        }
    }
}
